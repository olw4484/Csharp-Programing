﻿namespace _01.HelloWorld
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "김민수";
            int age = 32;
            float hight = 173.5f;
            string self = "안녕하세요. 제 이름은 김민수입니다. \n나이는 32세, 키는 173.5cm입니다.";
           Console.WriteLine(name);
            Console.WriteLine(age);
            Console.WriteLine(hight);
            Console.WriteLine(self);
        }
    }
}
